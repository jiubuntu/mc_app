let tMap = {
    map: null,
    marker_s: null,
    marker_e: null,
    marker_p1: null,
    marker_p2: null,
	totalMarkerArr: [],
	drawInfoArr: [],
	resultdrawArr: [],

    initTmap: () => {
        map = new Tmapv2.Map("map_div", {
            center : new Tmapv2.LatLng(37.56520450, 126.98702028),
                width : "100%",
                height : "800px",
                //default zoom : 17,
                zoom : 12,
                zoomControl : true,
                scrollwheel : true
        });     
    },
    
    start_marker: ( start_x, start_y)  => {
        let start_marker = new Tmapv2.Marker({
                position : new Tmapv2.LatLng(start_y, start_x),
                icon : "http://tmapapi.sktelecom.com/upload/tmap/marker/pin_r_m_s.png",
                iconSize : new Tmapv2.Size(24, 38),
                map : map
        });
		tMap.totalMarkerArr.push( start_marker );
    },

    end_marker: ( end_x, end_y ) => {
		let end_marker = new Tmapv2.Marker({
                position : new Tmapv2.LatLng(end_y, end_x),
                icon : "http://tmapapi.sktelecom.com/upload/tmap/marker/pin_r_m_e.png",
                iconSize : new Tmapv2.Size(24, 38),
                map : map
            });
		tMap.totalMarkerArr.push( end_marker );
    },

    addComma: ( num ) => {
        var regexp = /\B(?=(\d{3})+(?!\d))/g;
		return num.toString().replace(regexp, ',');
    },

    drawLine: ( arrPoint ) => {
        var polyline_;

		polyline_ = new Tmapv2.Polyline({
			path : arrPoint,
			strokeColor : "#DD0000",
			strokeWeight : 6,
			map : map
		});
		tMap.resultdrawArr.push(polyline_);
    },
    Move_center: ( point_x, point_y ) => {
        var lonlat = new Tmapv2.LatLng(point_y, point_x);
        map.setCenter(lonlat); // 지도의 중심 좌표를 설정합니다.
   }
    
}
