$(function() {
    //지도 생성
    tMap.initTmap();


    $("#marker").on("click", function(){
        //버튼을 눌렀을 때 마커와 경로를 찍어준다.
        let input_start = $("#start").val();
        let input_goal = $("#goal").val();
        let start_latlon = [];
        let goal_latlon = [];
        
        //마커를 그린 후 시작점과 도착점 좌표를 가진 2차원 배열 return
        let position_arr = APILOAD.get_geocode_ajax( input_start, input_goal );
        //지도의 센터 좌표 맞춰줌
        tMap.Move_center( position_arr[0][0], position_arr[0][1] );
		//이미 그려져 있는 마커가 있으면 지움.
		if (tMap.totalMarkerArr.length > 0) {
			for ( var i in tMap.totalMarkerArr) {
				tMap.totalMarkerArr[i]
						.setMap(null);
			}
			tMap.totalMarkerArr = [];
		}
		
//		if (tMap.drawInfoArr.length > 0) {
//			for ( var i in tMap.drawInfoArr) {
//				console.log(i);
//				tMap.drawInfoArr[i]
//						.setMap(null);
//			}
//			tMap.drawInfoArr = [];
//		}
        tMap.start_marker( position_arr[0][0], position_arr[0][1] );
        tMap.end_marker( position_arr[1][0], position_arr[1][1] );
        //경로표시
        APILOAD.get_tMap_route( position_arr );
            
    });
});
